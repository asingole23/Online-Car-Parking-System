package com.app.pojos;

public enum PaymentMode {
	DEBIT_CARD,CREDIT_CARD,NET_BANKING,UPI,WALLET

}
